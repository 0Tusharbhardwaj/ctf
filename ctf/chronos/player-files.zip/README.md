# VOID // Project Chronos: The Ghost in the Reactor

**Category:** Reversing  
**Points:** 500  
**Flag format:** `VOID{...}`

Chronos stopped halfway through a scientific pipeline. Recover the active closure graph from a stripped OCaml native executable, a deterministic heap snapshot, a C plugin, and a noisy telemetry trace. Reconstruct the post-mutation state and submit its normalized report to the verifier.

A recovery archive from the decommissioned Sub-Level 4 telemetry node contains the Chronos engine and evidence captured during a failed containment calculation. The old runtime is unfamiliar, and several closures share code while carrying different saved values.

## Files

- `chronos_engine` — stripped OCaml native executable
- `libcontainment.so` — native plugin loaded by the executable
- `core_heap.snapshot` — captured heap records
- `sensor_stream.raw` — noisy telemetry and execution trace
- `runtime-note.txt` — relevant format and runtime notes

Run the executable on Linux x86-64 with the included shared library in the same directory:

```sh
chmod +x chronos_engine
./chronos_engine
```

The service accepts one JSON report line per TCP connection. Connect to the host and port supplied by the organizers, then submit the reconstructed report as one line. A correct report returns the flag.
